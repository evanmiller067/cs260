Hello Mr. Noel,

I still haven't been able to get the averages to work, 
there is one block of data lost somewhere in the addData function. 
If you have time could you please tell me where my mistakes are? 
I've aleady asked and studdied with my fellow classmates and that got me this far.
I don't want to spend too much more time on this assignment when I should be focusing on the Rover assignment.

Thanks!

Evan Miller  
