This assignment includes several files:

- readme.txt 		 this file

- instructions.txt	 detailed assignment instructions

- background.txt 	 a (very) short story giving background and context
  			 for the assignment. This file is optional and you
  			 don't have to read it. It is just for fun.

- design_questions.txt	 the design questions that must be answered for the
  			 "design" portion of this assignment. 

- weatherlog.cpp	 the main driver for this program. You must use this 
  			 for your main().

- climatedata.txt 	 an example of the climate data file

- expected.txt		 the expected results when you use climatedata.txt

- rubric.txt		 the grading rubric for this assignment

