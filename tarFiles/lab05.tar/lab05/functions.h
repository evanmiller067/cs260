#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void doAverage(int x, int y);
int doGCD(int x, int y);
int doLCM(int x, int y);

#endif
