#ifndef RESULTDATA_H
#define RESULTDATA_H

class resultdata
{
	private:
		int data[4];
	public:
		void add(int, int, int, int);
		void print();
};
#endif
