#include "table.h"

//Please put the impelementation of the required functions here

int sumOfNodes(node *root)
{
	int sum;
	if(root != nullptr)
	{
	sum = root->data;
	sum = sum + sumOfNodes(root->left);	
	sum = sum + sumOfNodes(root->right);
	}
	return sum;
}

/*
void copyLeaf(node* src, node* &dest)
{	node* curr;
	node* temp;
	if(root != nullptr)
	{
		if(root->left != nullptr)
        }
	//start copy
	node* curr = node;
        while(curr->left != nullptr)
        {
                curr = curr->left;
        }
        sum = curr->data;
}

*/  
